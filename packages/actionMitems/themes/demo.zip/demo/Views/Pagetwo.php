<?php

namespace packages\actionMitems\themes\example\Views;
use packages\actionMitems\Views\Pagetwo as BootstrapView;
use packages\actionMitems\themes\example\Components\Components;

class Pagetwo extends BootstrapView {

    public $layout;
    public $title;

    /* @var Components */
    public $components;
    public $tab;




}
